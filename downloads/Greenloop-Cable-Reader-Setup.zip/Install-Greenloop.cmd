@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Cable-Reader.ps1"
set "setupExit=%ERRORLEVEL%"
echo.
pause
exit /b %setupExit%

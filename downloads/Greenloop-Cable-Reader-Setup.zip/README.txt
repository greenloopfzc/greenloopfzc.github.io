Greenloop Cable Reader - Windows 10/11 x64

Extract All first, then double-click Install-Greenloop.cmd.
Install once on EACH computer where phones connect. Do not run from inside ZIP.
If using PowerShell in this extracted folder:
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Install-Cable-Reader.ps1"

Android tools download from Google using stable-channel metadata, verified size and checksum.
iPhone: install Apple Devices from Microsoft Store if the driver is missing. Unlock and tap Trust.
Android: enable USB debugging, allow the computer and install official OEM USB drivers if required.
Open Greenloop on the SAME computer as the connected phone. Allow browser local-network access when requested.
This package includes the battery-health source fix. Capacity estimates remain labeled Estimated.
No business records, Supabase settings or Defender settings are changed.
Reader tool sources/licenses: https://greenloopfzc.github.io/downloads/reader-sources.zip

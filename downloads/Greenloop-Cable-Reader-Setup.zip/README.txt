Greenloop Cable Reader: install once using Install-Greenloop.cmd.
Existing working reader: run Repair-Autostart.cmd once to repair Windows sign-in startup without reinstalling phone tools.
Log in to your normal Windows account after restart; background reader starts automatically, also on battery power.
No phone stock or business records are changed. Unlock the connected phone and approve Trust / USB debugging.

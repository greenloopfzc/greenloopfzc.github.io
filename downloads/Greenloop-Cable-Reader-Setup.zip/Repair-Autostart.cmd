@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-Autostart.ps1"
if errorlevel 1 echo Auto-start repair did not finish. Share the message above.
pause
